<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Спорт КУКОЛД</title>
    <link rel="stylesheet" href="{{ asset('css/bets.css') }}">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    
    <style>
        .muted { color: #6b7280; font-size: 12px; }
        .wrap { word-break: break-word; }
        .collapsible .collapse-toggle { cursor: pointer; display: inline-flex; align-items: center; gap: 6px; font-size: 14px; padding: 6px 10px; }
        .collapsible .arrow { font-size: 16px; line-height: 1; }
        .collapsible.is-collapsed .collapsible-body { display: none; }
        .row-between { display: flex; align-items: center; justify-content: space-between; }
        .card-header { margin-bottom: 8px; }
    </style>
    </head>
<body>
    <header>
        <div class="container">
            <div class="logo">SPORT-KUCKOLD</div>
            <div class="description">Для тех кто любит смотреть спорт</div>
        </div>
    </header>
    <main>
        <div class="container">
            <div class="row">
                <h1>Линия событий</h1>
            </div>
            <div class="card mt-20">
                <h2>События</h2>
                @php($events = $events ?? [])
                @if(empty($events))
                    <p class="muted">Нет событий.</p>
                @else
                    <table class="responsive-table">
                        <thead>
                            <tr>
                                <th>Матч</th>
                                <th>Дата/время</th>
                                <th>Коэфф. (Д/Н/Г)</th>
                                <th>Статус</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($events as $ev)
                                <tr>
                                    <td data-label="Матч">
                                        @if(!empty($ev->home_team) && !empty($ev->away_team))
                                            {{ $ev->home_team }} vs {{ $ev->away_team }}
                                        @else
                                            {{ $ev->title ?? ('Event #'.$ev->id) }}
                                        @endif
                                    </td>
                                    <td data-label="Дата/время">
                                        {{ $ev->starts_at ? $ev->starts_at->format('d.m.Y H:i') : '—' }}
                                    </td>
                                    <td data-label="Коэфф. (Д/Н/Г)">
                                        @php($h = $ev->home_odds)
                                        @php($d = $ev->draw_odds)
                                        @php($a = $ev->away_odds)
                                        @if($h && $d && $a)
                                            @if(($ev->status ?? 'scheduled') === 'scheduled')
                                                <span class="odd-btn" data-event-id="{{ $ev->id }}" data-selection="home" data-home="{{ $ev->home_team ?? '' }}" data-away="{{ $ev->away_team ?? '' }}" data-odds="{{ number_format($h, 2) }}">{{ number_format($h, 2) }}</span>
                                                <span class="sep">/</span>
                                                <span class="odd-btn" data-event-id="{{ $ev->id }}" data-selection="draw" data-home="{{ $ev->home_team ?? '' }}" data-away="{{ $ev->away_team ?? '' }}" data-odds="{{ number_format($d, 2) }}">{{ number_format($d, 2) }}</span>
                                                <span class="sep">/</span>
                                                <span class="odd-btn" data-event-id="{{ $ev->id }}" data-selection="away" data-home="{{ $ev->home_team ?? '' }}" data-away="{{ $ev->away_team ?? '' }}" data-odds="{{ number_format($a, 2) }}">{{ number_format($a, 2) }}</span>
                                            @else
                                                {{ number_format($h, 2) }} / {{ number_format($d, 2) }} / {{ number_format($a, 2) }}
                                            @endif
                                        @else
                                            —
                                        @endif
                                    </td>
                                    <td data-label="Статус">{{ $ev->status ?? '—' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                @endif
            </div>

            <div class="card mt-20">
                <div id="vue-app" data-csrf="{{ csrf_token() }}" data-post-url="{{ route('bets.store') }}"></div>
            </div>

            @php($coupons = $coupons ?? [])
            <div class="card mt-20">
                <h2>Последние ставки (купоны)</h2>
                @if(empty($coupons))
                    <p class="muted">История ставок пуста.</p>
                @else
                <table class="responsive-table">
                    <thead>
                        <tr>
                            <th>Купон ID</th>
                            <th>Игрок</th>
                            <th>События (экспресс)</th>
                            <th>Сумма</th>
                            <th>Итоговый кэф</th>
                            <th>Потенц. выплата</th>
                            <th>Статус</th>
                            <th>Дата ставки</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($coupons as $coupon)
                            <tr>
                                <td>{{ $coupon->id }}</td>
                                <td>{{ $coupon->bettor_name }}</td>
                                <td>
                                    @foreach($coupon->bets as $l)
                                        <div>
                                            @if($l->event && $l->event->home_team && $l->event->away_team)
                                                {{ $l->event->home_team }} vs {{ $l->event->away_team }}
                                            @else
                                                {{ $l->event->title ?? ('Event #'.$l->event_id) }}
                                            @endif
                                            — выбор: {{ strtoupper($l->selection) }}
                                        </div>
                                    @endforeach
                                </td>
                                <td>{{ $coupon->amount_demo ? number_format($coupon->amount_demo, 2) : '—' }}</td>
                                <td>{{ $coupon->total_odds ? number_format($coupon->total_odds, 2) : '—' }}</td>
                                @php($potential = ($coupon->total_odds && $coupon->amount_demo) ? ($coupon->amount_demo * $coupon->total_odds) : null)
                                <td>{{ $potential ? number_format($potential, 2) : '—' }}</td>
                                <td>{{ $coupon->is_win === null ? '—' : ($coupon->is_win ? 'Выиграно' : 'Проигрыш') }}</td>
                                <td>{{ $coupon->created_at ? $coupon->created_at->format('Y-m-d H:i') : '—' }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
                @endif
            </div>

            

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.collapsible .collapse-toggle').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var wrap = btn.closest('.collapsible');
                if (!wrap) return;
                var arrow = btn.querySelector('.arrow');
                var isCollapsed = wrap.classList.toggle('is-collapsed');
                if (arrow) arrow.textContent = isCollapsed ? '▸' : '▾';
                btn.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
            });
        });
    });
    </script>

        </div>
    </main>
</body>
</html>