<template>
  <BetSlip />
</template>

<script setup>
import BetSlip from './components/BetSlip.vue'
</script>

<style scoped>
</style>