<template>
  <div>
    <h2 class="font-bold mb-10">Сделать демо-ставку</h2>
    <form @submit.prevent="submitAll" class="bet-form">
      <!-- Общая ошибка с плейсхолдером -->
      <div class="general-error" :class="errors.general ? 'general-error--visible' : 'general-error--placeholder'">{{ errors.general || ' ' }}</div>
      
      <div class="row row-start mb-4">
        <label for="bettor_name" class="form-label">Имя игрока</label>
        <input type="text" id="bettor_name" placeholder="Например: Иван" v-model="bettorName"
               :class="['border rounded-md px-3 py-2 focus:outline-none', errors.name ? 'border-red-500 focus:ring-2 focus:ring-red-500' : 'border-gray-300 focus:ring-2 focus:ring-blue-500']" />
        <p class="form-hint" :class="{ 'form-hint--error': !!errors.name, 'form-hint--empty': !errors.name }">{{ errors.name || ' ' }}</p>
      </div>
      
      <div class="row row-start mb-4">
        <div class="form-label">Купон</div>
        <ul id="slip-list">
          <li v-for="item in slip" :key="item.eventId" class="slip-item">
            <div class="row row-between">
              <div>
                <strong>{{ item.home && item.away ? `${item.home} vs ${item.away}` : `Event #${item.eventId}` }}</strong>
                <div class="muted">Исход: {{ selectionLabel(item.selection, item.home, item.away) }} • кэф {{ item.odds }}</div>
              </div>
              <button class="" type="button" @click="removeItem(item.eventId)">X</button>
            </div>
          </li>
        </ul>
        <div id="slip-empty" class="muted" v-show="slip.length === 0">
          Добавьте исходы, кликая по коэффициентам в таблице
        </div>
        <p class="form-hint" :class="{ 'form-hint--error': !!errors.slip, 'form-hint--empty': !errors.slip }">{{ errors.slip || ' ' }}</p>
      </div>
      <div class="row row-start mb-4">
        <label for="amount_demo" class="form-label">Сумма (демо)</label>
        <input type="number" id="amount_demo" placeholder="Например: 100" v-model.number="amountDemo"
               :class="['border rounded-md px-3 py-2 focus:outline-none', errors.amount ? 'border-red-500 focus:ring-2 focus:ring-red-500' : 'border-gray-300 focus:ring-2 focus:ring-blue-500']" />
        <p class="form-hint" :class="{ 'form-hint--error': !!errors.amount, 'form-hint--empty': !errors.amount }">{{ errors.amount || ' ' }}</p>
      </div>
      <div class="row">
        <button class="btn" type="button" @click="clearSlip" :disabled="slip.length === 0">Очистить</button>
        <button class="btn btn-primary" type="button" @click="submitAll" :disabled="disableSubmit">Поставить</button>
      </div>
    </form>
  </div>
</template>

<script setup>
import { onMounted, onBeforeUnmount, ref, computed } from 'vue'

const bettorName = ref('')
const amountDemo = ref(null)
const slip = ref([]) // [{ eventId, home, away, selection, odds }]
const submitting = ref(false)
const errors = ref({ name: null, amount: null, slip: null, general: null })

const selectionLabel = (sel, home, away) => {
  if (sel === 'home') return home || 'home'
  if (sel === 'away') return away || 'away'
  return 'draw'
}

function addOrReplaceSlipItem(item) {
  const idx = slip.value.findIndex(i => i.eventId === item.eventId)
  if (idx >= 0) slip.value[idx] = item
  else slip.value.push(item)
}

function removeItem(eventId) {
  slip.value = slip.value.filter(i => i.eventId !== eventId)
}

function clearSlip() {
  slip.value = []
}

function clearErrors() {
  errors.value = { name: null, amount: null, slip: null, general: null }
}

function validateForm() {
  clearErrors()
  let ok = true
  if (!bettorName.value || bettorName.value.trim().length === 0) {
    errors.value.name = 'Вы не заполнили имя игрока'
    ok = false
  }
  if (!amountDemo.value || Number(amountDemo.value) <= 0) {
    errors.value.amount = 'Введите сумму ставки'
    ok = false
  }
  if (slip.value.length === 0) {
    errors.value.slip = 'Вы не выбрали ни одного исхода'
    ok = false
  }
  return ok
}

const disableSubmit = computed(() => {
  // Блокируем кнопку только во время отправки, чтобы показать ошибки при клике
  return submitting.value
})

function handleOddClick(e) {
  const btn = e.target.closest('.odd-btn')
  if (!btn) return
  const eventId = btn.getAttribute('data-event-id')
  const selection = btn.getAttribute('data-selection')
  const home = btn.getAttribute('data-home')
  const away = btn.getAttribute('data-away')
  const odds = btn.getAttribute('data-odds')
  addOrReplaceSlipItem({ eventId, home, away, selection, odds })
}

async function submitAll() {
  if (submitting.value) return
  // Клиентская валидация
  if (!validateForm()) {
    return
  }
  submitting.value = true
  try {
    const rootEl = document.getElementById('vue-app')
    const csrfToken = rootEl?.dataset?.csrf || ''
    const postUrl = rootEl?.dataset?.postUrl || ''

    const items = slip.value.map(i => ({ event_id: Number(i.eventId), selection: i.selection }))
    const payload = {
      bettor_name: bettorName.value,
      amount_demo: Number(amountDemo.value),
      items,
    }

    const res = await fetch(postUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-CSRF-TOKEN': csrfToken,
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: JSON.stringify(payload),
    })

    if (!res.ok) {
      const text = await res.text()
      errors.value.general = 'Ошибка ставки: ' + text
      return
    }

    clearSlip()
    clearErrors()
    location.reload()
  } catch (e) {
    errors.value.general = e.message
  } finally {
    submitting.value = false
  }
}

onMounted(() => {
  document.addEventListener('click', handleOddClick)
})

onBeforeUnmount(() => {
  document.removeEventListener('click', handleOddClick)
})
</script>

<style scoped>
/* Дополнительные стили компонента при необходимости */
.general-error {
  min-height: 40px;
  margin-bottom: 1rem;
  border-radius: 0.375rem;
  padding: 0.5rem 0.75rem;
}
.general-error--placeholder {
  visibility: hidden;
}
.general-error--visible {
  visibility: visible;
  background-color: #fef2f2; /* red-50 */
  border: 1px solid #fecaca; /* red-200 */
  color: #b91c1c; /* red-700 */
}

/* Резервируем отступ под сообщение ошибки именно под блоком slip-empty */
#slip-empty {
  margin-bottom: 1.25rem; /* совпадает с высотой сообщения об ошибке */
}

.form-hint {
  min-height: 0; /* хинт сам не резервирует место, оно у slip-empty */
  font-size: 0.875rem; /* text-sm */
  margin-top: 0; /* чтобы не добавлять лишний сдвиг */
}
.form-hint--empty {
  display: none; /* скрываем хинт полностью, не влияя на раскладку */
}
.form-hint--error {
  color: #dc2626; /* text-red-600 */
}
</style>