<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Спорт КУКОЛД</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bets.css')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    
    <style>
        .muted { color: #6b7280; font-size: 12px; }
        .wrap { word-break: break-word; }
        .collapsible .collapse-toggle { cursor: pointer; display: inline-flex; align-items: center; gap: 6px; font-size: 14px; padding: 6px 10px; }
        .collapsible .arrow { font-size: 16px; line-height: 1; }
        .collapsible.is-collapsed .collapsible-body { display: none; }
        .row-between { display: flex; align-items: center; justify-content: space-between; }
        .card-header { margin-bottom: 8px; }
    </style>
    </head>
<body>
    <header>
        <div class="container">
            <div class="logo">SPORT-KUCKOLD</div>
            <div class="description">Для тех кто любит смотреть спорт</div>
        </div>
    </header>
    <main>
        <div class="container">
            <div class="row">
                <h1>Отладка результатов АПЛ</h1>
            </div>
            <?php if($error): ?>
                <p class="badge badge-info"><?php echo e($error); ?></p>
            <?php endif; ?>

            <div class="card mt-20">
                <h2>АПЛ — турнир</h2>
                <?php if(!empty($apiSportTournamentRaw)): ?>
                    <p class="muted">Турнир: <?php echo e(data_get($apiSportTournamentRaw, 'name')); ?> (ID: <?php echo e(data_get($apiSportTournamentRaw, 'id')); ?>)</p>
                    <p class="muted">Категория: <?php echo e(data_get($apiSportTournamentRaw, 'category.name')); ?> (ID: <?php echo e(data_get($apiSportTournamentRaw, 'category.id')); ?>)</p>
                <?php endif; ?>
            </div>

            <div class="card mt-20">
                <h2>Предстоящие матчи (неделя)</h2>
                <?php ($fx = $apiSportFixturesWeek ?? []); ?>
                <?php if(empty($fx)): ?>
                    <p class="muted">Нет предстоящих матчей на ближайшую неделю.</p>
                <?php else: ?>
                    <table class="responsive-table">
                        <thead>
                            <tr>
                                <th>Матч</th>
                                <th>Дата/время</th>
                                <th>Коэфф. (Д/Н/Г)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $fx; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-label="Матч">
                                        <?php if(!empty($m['home_team']) && !empty($m['away_team'])): ?>
                                            <?php echo e($m['home_team']); ?> vs <?php echo e($m['away_team']); ?>

                                        <?php else: ?>
                                            <?php echo e($m['title'] ?? '—'); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td data-label="Дата/время">
                                        <?php ($ct = $m['commence_time'] ?? null); ?>
                                        <?php echo e($ct ? \Illuminate\Support\Carbon::parse($ct)->format('d.m.Y H:i') : '—'); ?>

                                    </td>
                                    <td data-label="Коэфф. (Д/Н/Г)">
                                        <?php ($h = $m['home_odds'] ?? null); ?>
                                        <?php ($d = $m['draw_odds'] ?? null); ?>
                                        <?php ($a = $m['away_odds'] ?? null); ?>
                                        <?php ($eid = $m['event_id'] ?? null); ?>
                                        <?php if($h && $d && $a): ?>
                                            <?php if($eid): ?>
                                                <span class="odd-btn" data-event-id="<?php echo e($eid); ?>" data-selection="home" data-home="<?php echo e($m['home_team'] ?? ''); ?>" data-away="<?php echo e($m['away_team'] ?? ''); ?>" data-odds="<?php echo e(number_format($h, 2)); ?>"><?php echo e(number_format($h, 2)); ?></span>
                                                <span class="sep">/</span>
                                                <span class="odd-btn" data-event-id="<?php echo e($eid); ?>" data-selection="draw" data-home="<?php echo e($m['home_team'] ?? ''); ?>" data-away="<?php echo e($m['away_team'] ?? ''); ?>" data-odds="<?php echo e(number_format($d, 2)); ?>"><?php echo e(number_format($d, 2)); ?></span>
                                                <span class="sep">/</span>
                                                <span class="odd-btn" data-event-id="<?php echo e($eid); ?>" data-selection="away" data-home="<?php echo e($m['home_team'] ?? ''); ?>" data-away="<?php echo e($m['away_team'] ?? ''); ?>" data-odds="<?php echo e(number_format($a, 2)); ?>"><?php echo e(number_format($a, 2)); ?></span>
                                            <?php else: ?>
                                                <?php echo e(number_format($h, 2)); ?> / <?php echo e(number_format($d, 2)); ?> / <?php echo e(number_format($a, 2)); ?>

                                            <?php endif; ?>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div class="card mt-20">
                <div id="vue-app" data-csrf="<?php echo e(csrf_token()); ?>" data-post-url="<?php echo e(route('bets.store')); ?>"></div>
            </div>

            <?php ($coupons = $coupons ?? []); ?>
            <div class="card mt-20">
                <h2>Последние ставки (купоны)</h2>
                <?php if(empty($coupons)): ?>
                    <p class="muted">История ставок пуста.</p>
                <?php else: ?>
                <table class="responsive-table">
                    <thead>
                        <tr>
                            <th>Купон ID</th>
                            <th>Игрок</th>
                            <th>События (экспресс)</th>
                            <th>Сумма</th>
                            <th>Итоговый кэф</th>
                            <th>Потенц. выплата</th>
                            <th>Статус</th>
                            <th>Дата ставки</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($coupon->id); ?></td>
                                <td><?php echo e($coupon->bettor_name); ?></td>
                                <td>
                                    <?php $__currentLoopData = $coupon->bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <?php if($l->event && $l->event->home_team && $l->event->away_team): ?>
                                                <?php echo e($l->event->home_team); ?> vs <?php echo e($l->event->away_team); ?>

                                            <?php else: ?>
                                                <?php echo e($l->event->title ?? ('Event #'.$l->event_id)); ?>

                                            <?php endif; ?>
                                            — выбор: <?php echo e(strtoupper($l->selection)); ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($coupon->amount_demo ? number_format($coupon->amount_demo, 2) : '—'); ?></td>
                                <td><?php echo e($coupon->total_odds ? number_format($coupon->total_odds, 2) : '—'); ?></td>
                                <?php ($potential = ($coupon->total_odds && $coupon->amount_demo) ? ($coupon->amount_demo * $coupon->total_odds) : null); ?>
                                <td><?php echo e($potential ? number_format($potential, 2) : '—'); ?></td>
                                <td><?php echo e($coupon->is_win === null ? '—' : ($coupon->is_win ? 'Выиграно' : 'Проигрыш')); ?></td>
                                <td><?php echo e($coupon->created_at ? $coupon->created_at->format('Y-m-d H:i') : '—'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>

            <div class="card mt-20 collapsible is-collapsed" id="results-week">
                <div class="card-header row-between">
                    <h2>Результаты за прошлую неделю</h2>
                    <button type="button" class="collapse-toggle btn btn-secondary" aria-expanded="true" aria-controls="results-week-body">
                        <span class="arrow">▾</span>
                    </button>
                </div>
                <?php ($rw = $apiSportResultsWeek ?? []); ?>
                <?php if(empty($rw)): ?>
                    <p class="muted">Нет завершённых матчей за прошлую неделю.</p>
                <?php else: ?>
                    <div class="collapsible-body" id="results-week-body">
                    <table class="responsive-table">
                        <thead>
                            <tr>
                                <th>Матч</th>
                                <th>Дата/время</th>
                                <th>Счёт (Д-Г)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rw; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-label="Матч">
                                        <?php if(!empty($m['home_team']) && !empty($m['away_team'])): ?>
                                            <?php echo e($m['home_team']); ?> vs <?php echo e($m['away_team']); ?>

                                        <?php else: ?>
                                            <?php echo e($m['title'] ?? '—'); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td data-label="Дата/время">
                                        <?php ($ft = $m['finished_at'] ?? null); ?>
                                        <?php echo e($ft ? \Illuminate\Support\Carbon::parse($ft)->format('d.m.Y H:i') : '—'); ?>

                                    </td>
                                    <td data-label="Счёт (Д-Г)">
                                        <?php ($hs = $m['home_score'] ?? null); ?>
                                        <?php ($as = $m['away_score'] ?? null); ?>
                                        <?php if($hs !== null && $as !== null): ?>
                                            <?php echo e(is_numeric($hs) && is_numeric($as) ? ($hs.' — '.$as) : '—'); ?>

                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                <?php endif; ?>
            </div>

            <div class="card mt-20 collapsible is-collapsed" id="results-all">
                <div class="card-header row-between">
                    <h2>Все предыдущие результаты (сезон)</h2>
                    <button type="button" class="collapse-toggle btn btn-secondary" aria-expanded="true" aria-controls="results-all-body">
                        <span class="arrow">▾</span>
                        
                    </button>
                </div>
                <?php ($ra = $apiSportResultsAll ?? []); ?>
                <?php if(empty($ra)): ?>
                    <p class="muted">Нет завершённых матчей по фильтру сезона.</p>
                <?php else: ?>
                    <div class="collapsible-body" id="results-all-body">
                    <table class="responsive-table">
                        <thead>
                            <tr>
                                <th>Матч</th>
                                <th>Дата/время</th>
                                <th>Счёт (Д-Г)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-label="Матч">
                                        <?php if(!empty($m['home_team']) && !empty($m['away_team'])): ?>
                                            <?php echo e($m['home_team']); ?> vs <?php echo e($m['away_team']); ?>

                                        <?php else: ?>
                                            <?php echo e($m['title'] ?? '—'); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td data-label="Дата/время">
                                        <?php ($ft = $m['finished_at'] ?? null); ?>
                                        <?php echo e($ft ? \Illuminate\Support\Carbon::parse($ft)->format('d.m.Y H:i') : '—'); ?>

                                    </td>
                                    <td data-label="Счёт (Д-Г)">
                                        <?php ($hs = $m['home_score'] ?? null); ?>
                                        <?php ($as = $m['away_score'] ?? null); ?>
                                        <?php if($hs !== null && $as !== null): ?>
                                            <?php echo e(is_numeric($hs) && is_numeric($as) ? ($hs.' — '.$as) : '—'); ?>

                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                <?php endif; ?>
            </div>

            <div class="card mt-20 collapsible is-collapsed">
                <h2>Аналитика сезона</h2>
                
                <?php ($ag = $apiSportAggregates ?? null); ?>
                <?php if(!$ag): ?>
                    <p class="muted">Недостаточно данных для аналитики.</p>
                <?php else: ?>
                    <div class="wrap">
                        <p>
                            Самая забивающая команда: 
                            <strong><?php echo e(data_get($ag, 'most_scoring_overall.team') ?? '—'); ?></strong>
                            (голы: <?php echo e(data_get($ag, 'most_scoring_overall.goals') ?? '—'); ?>)
                        </p>
                        <p>
                            Самая забивающая команда в домашних матчах:
                            <strong><?php echo e(data_get($ag, 'most_scoring_home.team') ?? '—'); ?></strong>
                            (голы: <?php echo e(data_get($ag, 'most_scoring_home.goals') ?? '—'); ?>)
                        </p>
                        <p>
                            Самая забивающая команда в гостевых матчах:
                            <strong><?php echo e(data_get($ag, 'most_scoring_away.team') ?? '—'); ?></strong>
                            (голы: <?php echo e(data_get($ag, 'most_scoring_away.goals') ?? '—'); ?>)
                        </p>
                        <p>
                            Самая пропускаемая команда в домашних:
                            <strong><?php echo e(data_get($ag, 'most_conceding_home.team') ?? '—'); ?></strong>
                            (голы: <?php echo e(data_get($ag, 'most_conceding_home.goals') ?? '—'); ?>)
                        </p>
                        <p>
                            Самая пропускаемая команда в гостевых:
                            <strong><?php echo e(data_get($ag, 'most_conceding_away.team') ?? '—'); ?></strong>
                            (голы: <?php echo e(data_get($ag, 'most_conceding_away.goals') ?? '—'); ?>)
                        </p>
                    </div>

                    <div class="mt-10 " id="team-stats">
                        <div class="row-between">
                            <h3>Победы и поражения по командам</h3>
                            <button type="button" class="collapse-toggle btn btn-secondary" aria-expanded="true" aria-controls="team-stats-body">
                                <span class="arrow">▾</span>
                                
                            </button>
                        </div>
                    <?php ($ts = data_get($ag, 'team_stats', [])); ?>
                    <?php if(empty($ts)): ?>
                        <p class="muted">Нет статистики по командам.</p>
                    <?php else: ?>
                        <div class="collapsible-body" id="team-stats-body">
                        <table class="responsive-table">
                            <thead>
                                <tr>
                                    <th>Команда</th>
                                    <th>Дом (W/D/L)</th>
                                    <th>Дом (ГД-ГП)</th>
                                    <th>Гость (W/D/L)</th>
                                    <th>Гость (ГД-ГП)</th>
                                    <th>Итого (W/D/L)</th>
                                    <th>Матчи</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $ts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team => $st): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td data-label="Команда"><?php echo e($team); ?></td>
                                        <td data-label="Дом (W/D/L)">
                                            <?php echo e(($st['home']['wins'] ?? 0)); ?> / <?php echo e(($st['home']['draws'] ?? 0)); ?> / <?php echo e(($st['home']['losses'] ?? 0)); ?>

                                        </td>
                                        <td data-label="Дом (ГД-ГП)">
                                            <?php echo e(($st['home']['goals_for'] ?? 0)); ?> — <?php echo e(($st['home']['goals_against'] ?? 0)); ?>

                                        </td>
                                        <td data-label="Гость (W/D/L)">
                                            <?php echo e(($st['away']['wins'] ?? 0)); ?> / <?php echo e(($st['away']['draws'] ?? 0)); ?> / <?php echo e(($st['away']['losses'] ?? 0)); ?>

                                        </td>
                                        <td data-label="Гость (ГД-ГП)">
                                            <?php echo e(($st['away']['goals_for'] ?? 0)); ?> — <?php echo e(($st['away']['goals_against'] ?? 0)); ?>

                                        </td>
                                        <td data-label="Итого (W/D/L)">
                                            <?php echo e(($st['wins'] ?? 0)); ?> / <?php echo e(($st['draws'] ?? 0)); ?> / <?php echo e(($st['losses'] ?? 0)); ?>

                                        </td>
                                        <td data-label="Матчи"><?php echo e(($st['matches'] ?? 0)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        </div>
                    <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.collapsible .collapse-toggle').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var wrap = btn.closest('.collapsible');
                if (!wrap) return;
                var arrow = btn.querySelector('.arrow');
                var isCollapsed = wrap.classList.toggle('is-collapsed');
                if (arrow) arrow.textContent = isCollapsed ? '▸' : '▾';
                btn.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
            });
        });
    });
    </script>

        </div>
    </main>
</body>
</html><?php /**PATH /var/www/html/resources/views/debug-results.blade.php ENDPATH**/ ?>