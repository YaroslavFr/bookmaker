<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>sstats.net</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bets.css')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <style>
        .muted { color:#777; font-size:12px; }
        .grid { display:grid; grid-template-columns: 1fr; gap: 16px; }
        .card { background:#fff; border-radius:8px; padding:16px; box-shadow:0 1px 3px rgba(0,0,0,0.1); }
        table { width:100%; border-collapse: collapse; }
        th, td { padding:8px; border-bottom:1px solid #eee; text-align:left; }
        .badge { display:inline-block; padding:4px 8px; border-radius:4px; }
        .badge-info { background:#eef; color:#225; }
        .row { display:flex; gap:8px; align-items:center; }
    </style>
    </head>
<body>
    <header>
        <div class="container">
            <div class="logo">SSTATS.NET</div>
            <div class="description">Обзор API sstats.net: лиги, матчи, детали, коэффициенты</div>
        </div>
    </header>
    <main>
        <div class="container">
            <?php if(!empty($error)): ?>
                <p class="badge badge-info">Ошибка: <?php echo e($error); ?></p>
            <?php endif; ?>

            <div class="card">
                <div class="row row-between" style="justify-content: space-between;">
                    <h2>Английская Премьер-лига — предстоящие матчи</h2>
                </div>
                <div class="muted">Ключ: <?php echo e(config('services.sstats.key') ? 'задан' : 'не задан'); ?> · База: <?php echo e(config('services.sstats.base_url')); ?> · Лига: <?php echo e($leagueName ?? 'English Premier League'); ?></div>
            </div>

            

            <?php if($games): ?>
                <div class="card">
                    <h2>Английская Премьер-лига — предстоящие матчи (<?php echo e($year); ?>)</h2>
                    <table class="responsive-table">
                        <thead>
                            <tr>
                                <th>Дата</th>
                                <th>Матч</th>
                                <th>Статус</th>
                                <th>Коэфф. (Д/Н/Г)</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $homeOdd = null; $drawOdd = null; $awayOdd = null;
                                    $oddsList = $g['odds'] ?? [];
                                    if (is_array($oddsList)) {
                                        // Shape A: direct markets under $g['odds']
                                        foreach ($oddsList as $mk) {
                                            foreach (($mk['odds'] ?? []) as $o) {
                                                $sel = strtolower((string)($o['name'] ?? ($o['selectionName'] ?? '')));
                                                $val = $o['value'] ?? ($o['odd'] ?? ($o['rate'] ?? null));
                                                if ($val !== null) {
                                                    if ($homeOdd === null && (str_contains($sel, 'home') || $sel === '1')) { $homeOdd = $val; }
                                                    if ($drawOdd === null && (str_contains($sel, 'draw') || $sel === 'x')) { $drawOdd = $val; }
                                                    if ($awayOdd === null && (str_contains($sel, 'away') || $sel === '2')) { $awayOdd = $val; }
                                                }
                                            }
                                            if ($homeOdd !== null && $drawOdd !== null && $awayOdd !== null) { break; }
                                        }
                                        // Shape B: bookmaker -> markets -> odds
                                        if ($homeOdd === null || $drawOdd === null || $awayOdd === null) {
                                            foreach ($oddsList as $book) {
                                                foreach (($book['odds'] ?? []) as $market) {
                                                    $mName = strtolower((string)($market['marketName'] ?? ''));
                                                    if (str_contains($mName, '1x2') || str_contains($mName, 'full time') || str_contains($mName, 'match odds')) {
                                                        foreach (($market['odds'] ?? []) as $o) {
                                                            $sel = strtolower((string)($o['name'] ?? ($o['selectionName'] ?? '')));
                                                            $val = $o['value'] ?? ($o['odd'] ?? ($o['rate'] ?? null));
                                                            if ($val !== null) {
                                                                if ($homeOdd === null && (str_contains($sel, 'home') || $sel === '1')) { $homeOdd = $val; }
                                                                if ($drawOdd === null && (str_contains($sel, 'draw') || $sel === 'x')) { $drawOdd = $val; }
                                                                if ($awayOdd === null && (str_contains($sel, 'away') || $sel === '2')) { $awayOdd = $val; }
                                                            }
                                                        }
                                                        break;
                                                    }
                                                }
                                                if ($homeOdd !== null && $drawOdd !== null && $awayOdd !== null) { break; }
                                            }
                                        }
                                    }
                                ?>
                                <tr>
                                    <td data-label="Дата"><?php echo e($g['date'] ?? ''); ?></td>
                                    <td data-label="Матч"><?php echo e(data_get($g,'homeTeam.name')); ?> vs <?php echo e(data_get($g,'awayTeam.name')); ?></td>
                                    <td data-label="Статус"><?php echo e($g['statusName'] ?? ($g['status'] ?? '')); ?></td>
                                    <td data-label="Коэфф. (Д/Н/Г)">
                                        <?php if($homeOdd && $drawOdd && $awayOdd): ?>
                                            <?php echo e(number_format((float)$homeOdd, 2)); ?> / <?php echo e(number_format((float)$drawOdd, 2)); ?> / <?php echo e(number_format((float)$awayOdd, 2)); ?>

                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

            <?php if($game): ?>
                <div class="card">
                    <h2>Матч #<?php echo e($game['game']['id'] ?? $game['id'] ?? ''); ?></h2>
                    <?php $gi = $game['game'] ?? $game; ?>
                    <div class="row" style="gap:24px; align-items:flex-start;">
                        <div style="flex:1;">
                            <h3>Основное</h3>
                            <p><strong>Дата:</strong> <?php echo e($gi['date'] ?? ''); ?></p>
                            <p><strong>Матч:</strong> <?php echo e(data_get($gi,'homeTeam.name')); ?> vs <?php echo e(data_get($gi,'awayTeam.name')); ?></p>
                            <p><strong>Лига:</strong> <?php echo e(data_get($gi,'season.league.name')); ?> (<?php echo e(data_get($gi,'season.year')); ?>)</p>
                            <p><strong>Счёт:</strong> <?php echo e($gi['homeResult'] ?? ''); ?> : <?php echo e($gi['awayResult'] ?? ''); ?></p>
                            <p><strong>Статус:</strong> <?php echo e($gi['statusName'] ?? ($gi['status'] ?? '')); ?></p>
                        </div>
                        <div style="flex:1;">
                            <h3>Коэффициенты (prematch)</h3>
                            <?php if($odds): ?>
                                <?php $__currentLoopData = $odds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card" style="margin-bottom:8px;">
                                        <div><strong><?php echo e($book['bookmakerName'] ?? ('Bookmaker '.$book['bookmakerId'] ?? '')); ?></strong></div>
                                        <?php $__currentLoopData = ($book['odds'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="muted"><?php echo e($market['marketName'] ?? ('Market '.$market['marketId'] ?? '')); ?></div>
                                            <div class="row" style="flex-wrap:wrap;">
                                                <?php $__currentLoopData = ($market['odds'] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge badge-info"><?php echo e($o['name']); ?>: <?php echo e($o['value']); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <div class="muted">Нет данных по коэффициентам</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <h3>Glicko 2</h3>
                    <?php if($glicko): ?>
                        <pre style="white-space:pre-wrap;"><?php echo e(json_encode($glicko, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)); ?></pre>
                    <?php else: ?>
                        <div class="muted">Нет данных Glicko</div>
                    <?php endif; ?>
                </div>

                <div class="card">
                    <h3>Анализ прибыльности</h3>
                    <?php if($profits): ?>
                        <pre style="white-space:pre-wrap;"><?php echo e(json_encode($profits, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE)); ?></pre>
                    <?php else: ?>
                        <div class="muted">Нет данных по прибыльности</div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </main>
</body>
</html><?php /**PATH /var/www/html/resources/views/sstats.blade.php ENDPATH**/ ?>