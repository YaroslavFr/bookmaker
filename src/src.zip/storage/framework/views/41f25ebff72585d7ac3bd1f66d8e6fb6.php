<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Спорт КУКОЛД</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bets.css')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    
    <style>
        .muted { color: #6b7280; font-size: 12px; }
        .wrap { word-break: break-word; }
        .collapsible .collapse-toggle { cursor: pointer; display: inline-flex; align-items: center; gap: 6px; font-size: 14px; padding: 6px 10px; }
        .collapsible .arrow { font-size: 16px; line-height: 1; }
        .collapsible.is-collapsed .collapsible-body { display: none; }
        .row-between { display: flex; align-items: center; justify-content: space-between; }
        .card-header { margin-bottom: 8px; }
    </style>
    </head>
<body>
    <header>
        <div class="container">
            <div class="logo">SPORT-KUCKOLD</div>
            <div class="description">Для тех кто любит смотреть спорт</div>
        </div>
    </header>
    <main>
        <div class="container">
            <div class="row">
                <h1>Линия событий</h1>
            </div>
            <div class="card mt-20">
                <h2>События</h2>
                <?php ($events = $events ?? []); ?>
                <?php if(empty($events)): ?>
                    <p class="muted">Нет событий.</p>
                <?php else: ?>
                    <table class="responsive-table">
                        <thead>
                            <tr>
                                <th>Матч</th>
                                <th>Дата/время</th>
                                <th>Коэфф. (Д/Н/Г)</th>
                                <th>Статус</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-label="Матч">
                                        <?php if(!empty($ev->home_team) && !empty($ev->away_team)): ?>
                                            <?php echo e($ev->home_team); ?> vs <?php echo e($ev->away_team); ?>

                                        <?php else: ?>
                                            <?php echo e($ev->title ?? ('Event #'.$ev->id)); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td data-label="Дата/время">
                                        <?php echo e($ev->starts_at ? $ev->starts_at->format('d.m.Y H:i') : '—'); ?>

                                    </td>
                                    <td data-label="Коэфф. (Д/Н/Г)">
                                        <?php ($h = $ev->home_odds); ?>
                                        <?php ($d = $ev->draw_odds); ?>
                                        <?php ($a = $ev->away_odds); ?>
                                        <?php if($h && $d && $a): ?>
                                            <?php if(($ev->status ?? 'scheduled') === 'scheduled'): ?>
                                                <span class="odd-btn" data-event-id="<?php echo e($ev->id); ?>" data-selection="home" data-home="<?php echo e($ev->home_team ?? ''); ?>" data-away="<?php echo e($ev->away_team ?? ''); ?>" data-odds="<?php echo e(number_format($h, 2)); ?>"><?php echo e(number_format($h, 2)); ?></span>
                                                <span class="sep">/</span>
                                                <span class="odd-btn" data-event-id="<?php echo e($ev->id); ?>" data-selection="draw" data-home="<?php echo e($ev->home_team ?? ''); ?>" data-away="<?php echo e($ev->away_team ?? ''); ?>" data-odds="<?php echo e(number_format($d, 2)); ?>"><?php echo e(number_format($d, 2)); ?></span>
                                                <span class="sep">/</span>
                                                <span class="odd-btn" data-event-id="<?php echo e($ev->id); ?>" data-selection="away" data-home="<?php echo e($ev->home_team ?? ''); ?>" data-away="<?php echo e($ev->away_team ?? ''); ?>" data-odds="<?php echo e(number_format($a, 2)); ?>"><?php echo e(number_format($a, 2)); ?></span>
                                            <?php else: ?>
                                                <?php echo e(number_format($h, 2)); ?> / <?php echo e(number_format($d, 2)); ?> / <?php echo e(number_format($a, 2)); ?>

                                            <?php endif; ?>
                                        <?php else: ?>
                                            —
                                        <?php endif; ?>
                                    </td>
                                    <td data-label="Статус"><?php echo e($ev->status ?? '—'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div class="card mt-20">
                <div id="vue-app" data-csrf="<?php echo e(csrf_token()); ?>" data-post-url="<?php echo e(route('bets.store')); ?>"></div>
            </div>

            <?php ($coupons = $coupons ?? []); ?>
            <div class="card mt-20">
                <h2>Последние ставки (купоны)</h2>
                <?php if(empty($coupons)): ?>
                    <p class="muted">История ставок пуста.</p>
                <?php else: ?>
                <table class="responsive-table">
                    <thead>
                        <tr>
                            <th>Купон ID</th>
                            <th>Игрок</th>
                            <th>События (экспресс)</th>
                            <th>Сумма</th>
                            <th>Итоговый кэф</th>
                            <th>Потенц. выплата</th>
                            <th>Статус</th>
                            <th>Дата ставки</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($coupon->id); ?></td>
                                <td><?php echo e($coupon->bettor_name); ?></td>
                                <td>
                                    <?php $__currentLoopData = $coupon->bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <?php if($l->event && $l->event->home_team && $l->event->away_team): ?>
                                                <?php echo e($l->event->home_team); ?> vs <?php echo e($l->event->away_team); ?>

                                            <?php else: ?>
                                                <?php echo e($l->event->title ?? ('Event #'.$l->event_id)); ?>

                                            <?php endif; ?>
                                            — выбор: <?php echo e(strtoupper($l->selection)); ?>

                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </td>
                                <td><?php echo e($coupon->amount_demo ? number_format($coupon->amount_demo, 2) : '—'); ?></td>
                                <td><?php echo e($coupon->total_odds ? number_format($coupon->total_odds, 2) : '—'); ?></td>
                                <?php ($potential = ($coupon->total_odds && $coupon->amount_demo) ? ($coupon->amount_demo * $coupon->total_odds) : null); ?>
                                <td><?php echo e($potential ? number_format($potential, 2) : '—'); ?></td>
                                <td><?php echo e($coupon->is_win === null ? '—' : ($coupon->is_win ? 'Выиграно' : 'Проигрыш')); ?></td>
                                <td><?php echo e($coupon->created_at ? $coupon->created_at->format('Y-m-d H:i') : '—'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>

            

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.collapsible .collapse-toggle').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var wrap = btn.closest('.collapsible');
                if (!wrap) return;
                var arrow = btn.querySelector('.arrow');
                var isCollapsed = wrap.classList.toggle('is-collapsed');
                if (arrow) arrow.textContent = isCollapsed ? '▸' : '▾';
                btn.setAttribute('aria-expanded', isCollapsed ? 'false' : 'true');
            });
        });
    });
    </script>

        </div>
    </main>
</body>
</html><?php /**PATH /var/www/html/resources/views/home.blade.php ENDPATH**/ ?>